### <center>Name Jialiang Xiao(NUID 001569847)</center>

# <center>Program Structures & Algorithms</center>

# <center>Spring 2021</center>

# <center>Assignment No.2</center>

### Task

#### Step1

(a) Implement height-weighted Quick Union with Path Compression. For this, you will flesh out the class UF_HWQUPC. All you have to do is to fill in 		the sections marked with // TO BE IMPLEMENTED ... // ...END IMPLEMENTATION.

(b) Check that the unit tests for this class all work. You must show "green" test results in your submission (screenshot is OK). 

#### Step2

Using your implementation of UF_HWQUPC, develop a UF ("union-find") client that takes an integer value n from the command line to determine the 		number of "sites." Then generates random pairs of integers between 0 and n-1, calling connected() to determine if they are connected and union() if not. Loop until all sites are connected then print the number of connections generated. Package your program as a static method count() that takes n as the argument and returns the number of connections; and a main() that takes n from the command line, calls count() and prints the returned  value. If you prefer, you can create a main program that doesn't require any input and runs the experiment for a fixed set of n values. Show evidence of your run(s).

#### Step3

Determine the relationship between the number of objects (*n*) and the number of pairs (*m*) generated to accomplish this (i.e. to reduce the number 		of components from *n* to 1). Justify your conclusion.

Don't forget to follow the submission guidelines. And to use sufficient (and sufficiently large) different values of n.

### Output

The screenshots of the unit tests of my implementation of the class UF_HWQUPC(**Step1**) and the runs of my client(**Step2**) are presented in the 			**Screenshots** chapter.

For **Step3**, my expression of the relationship between n and m is **m=-2.87675140e+01\*n^0.5 + 4.63335854e+00\*n + 6.93333568e-05\*n^2 + -1.49068171e-09\*n^3**. Approximately, we can assume the relations is **m=4.65\*n - 30\*n^0.5**.

The results of my experiment performed for **Step3** are as follows. Details can be found in the Experiment_Result.csv(10,000 sites) and Experiment_Result2(20,000sites).csv.

![截屏2021-02-16 下午5.17.17](/Users/xiaojialiang/Desktop/截屏2021-02-16 下午5.17.17.png)



![截屏2021-02-16 下午5.17.28](/Users/xiaojialiang/Desktop/截屏2021-02-16 下午5.17.28.png)

### Graphical Representation 

The scatter plot of the result of experiment for **Step3** are as follows.

#### Experiment 1

![截屏2021-02-16 下午5.21.19](/Users/xiaojialiang/Library/Application Support/typora-user-images/截屏2021-02-16 下午5.21.19.png)

#### Experiment 2

![截屏2021-02-16 下午5.22.17](/Users/xiaojialiang/Library/Application Support/typora-user-images/截屏2021-02-16 下午5.22.17.png)

### Justification

In general, I first observed the scatter plot of my two experiments. I found they follows approximately linear relation. Next I guessed the expression of the relation to be m = a\*n^0.5 + b\*n + c\*n^2 + d\*n^3. I performed least squares method on both datasets of two experiments. After that, I found the coefficient b is almost equal for the expressions came out on two experiments. So I decided to use the expression based on the second experiment as the final conclusion. The results of least squares method approximation can be found in **Screenshots** charpter.

### Screenshots

Unit tests result of **Step1**:

![截屏2021-02-13 下午5.50.47 (2)](/Users/xiaojialiang/Desktop/截屏2021-02-13 下午5.50.47 (2).png)



Runs result of **Step2**:

![截屏2021-02-14 下午3.58.56 (2)](/Users/xiaojialiang/Desktop/截屏2021-02-14 下午3.58.56 (2).png)



Runs result of **Step3:**

![截屏2021-02-16 下午5.39.02 (2)](/Users/xiaojialiang/Desktop/截屏2021-02-16 下午5.39.02 (2).png)



Result of **two least squares method approximation:**

Approximation based on experiment1

![截屏2021-02-16 下午5.41.05](/Users/xiaojialiang/Library/Application Support/typora-user-images/截屏2021-02-16 下午5.41.05.png)

Approximation based on experiment2

![截屏2021-02-16 下午5.42.14](/Users/xiaojialiang/Library/Application Support/typora-user-images/截屏2021-02-16 下午5.42.14.png)

### Code

#### UF_HWQUPC.java (Step1)

```java
/**
 * Original code:
 * Copyright © 2000–2017, Robert Sedgewick and Kevin Wayne.
 * <p>
 * Modifications:
 * Copyright (c) 2017. Phasmid Software
 */
package edu.neu.coe.info6205.union_find;

import java.util.Arrays;

/**
 * Height-weighted Quick Union with Path Compression
 */
public class UF_HWQUPC implements UF {
    /**
     * Ensure that site p is connected to site q,
     *
     * @param p the integer representing one site
     * @param q the integer representing the other site
     */
    public void connect(int p, int q) {
        if (!isConnected(p, q)) union(p, q);
    }

    /**
     * Initializes an empty union–find data structure with {@code n} sites
     * {@code 0} through {@code n-1}. Each site is initially in its own
     * component.
     *
     * @param n               the number of sites
     * @param pathCompression whether to use path compression
     * @throws IllegalArgumentException if {@code n < 0}
     */
    public UF_HWQUPC(int n, boolean pathCompression) {
        count = n;
        parent = new int[n];
        height = new int[n];
        for (int i = 0; i < n; i++) {
            parent[i] = i;
            height[i] = 1;
        }
        this.pathCompression = pathCompression;
    }

    /**
     * Initializes an empty union–find data structure with {@code n} sites
     * {@code 0} through {@code n-1}. Each site is initially in its own
     * component.
     * This data structure uses path compression
     *
     * @param n the number of sites
     * @throws IllegalArgumentException if {@code n < 0}
     */
    public UF_HWQUPC(int n) {
        this(n, true);
    }

    public void show() {
        for (int i = 0; i < parent.length; i++) {
            System.out.printf("%d: %d, %d\n", i, parent[i], height[i]);
        }
    }

    /**
     * Returns the number of components.
     *
     * @return the number of components (between {@code 1} and {@code n})
     */
    public int components() {
        return count;
    }

    /**
     * Returns the component identifier for the component containing site {@code p}.
     *
     * @param p the integer representing one site
     * @return the component identifier for the component containing site {@code p}
     * @throws IllegalArgumentException unless {@code 0 <= p < n}
     */
    public int find(int p) {
        validate(p);
        int root = p;
        // TO BE IMPLEMENTED 在此处应该有path compression, notice in the class there is boolean pathCompression to determine whether the pathCompression is invoked or not
        while (root != parent[p]){
            if(pathCompression==true){
                doPathCompression(root);
            }
            root=getParent(p);
            p=getParent(p);
        }

        return root;
    }

    /**
     * Returns true if the the two sites are in the same component.
     *
     * @param p the integer representing one site
     * @param q the integer representing the other site
     * @return {@code true} if the two sites {@code p} and {@code q} are in the same component;
     * {@code false} otherwise
     * @throws IllegalArgumentException unless
     *                                  both {@code 0 <= p < n} and {@code 0 <= q < n}
     */
    public boolean connected(int p, int q) {
        return find(p) == find(q);
    }

    /**
     * Merges the component containing site {@code p} with the
     * the component containing site {@code q}.
     *
     * @param p the integer representing one site
     * @param q the integer representing the other site
     * @throws IllegalArgumentException unless
     *                                  both {@code 0 <= p < n} and {@code 0 <= q < n}
     */
    public void union(int p, int q) {
        // CONSIDER can we avoid doing find again? but how?
        mergeComponents(find(p), find(q));
        count--;
    }

    @Override
    public int size() {
        return parent.length;
    }

    /**
     * Used only by testing code
     *
     * @param pathCompression true if you want path compression
     */
    public void setPathCompression(boolean pathCompression) {
        this.pathCompression = pathCompression;
    }

    @Override
    public String toString() {
        return "UF_HWQUPC:" + "\n  count: " + count +
                "\n  path compression? " + pathCompression +
                "\n  parents: " + Arrays.toString(parent) +
                "\n  heights: " + Arrays.toString(height);
    }

    // validate that p is a valid index
    private void validate(int p) {
        int n = parent.length;
        if (p < 0 || p >= n) {
            throw new IllegalArgumentException("index " + p + " is not between 0 and " + (n - 1));
        }
    }

    private void updateParent(int p, int x) {
        parent[p] = x;
    }

    private void updateHeight(int p, int x) {
        height[p] += height[x];
    }

    /**
     * Used only by testing code
     *
     * @param i the component
     * @return the parent of the component
     */
    private int getParent(int i) {
        return parent[i];
    }

    private final int[] parent;   // parent[i] = parent of i
    private final int[] height;   // height[i] = height of subtree rooted at i
    private int count;  // number of components
    private boolean pathCompression;

    private void mergeComponents(int i, int j) {
        // TO BE IMPLEMENTED make shorter root point to taller one
        if(i==j) return;
        if(height[i]<height[j]){
            updateParent(i,j);
            updateHeight(j,i);
        }else{
            updateParent(j,i);
            updateHeight(i,j);
        }
    }

    /**
     * This implements the single-pass path-halving mechanism of path compression
     */
    private void doPathCompression(int i) {
        // TO BE IMPLEMENTED update parent to value of grandparent
        parent[i] = parent[parent[i]];
    }
}

```



#### DynamicConnectivityClient.java (Step2&3)

```java
package edu.neu.coe.info6205.union_find;

import edu.neu.coe.info6205.util.FileHandler;
import edu.neu.coe.info6205.util.FileHandlerImpl_CSV;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * This class is a client for dynamic connectivity problem solved with UF_HWQUPC.
 * The main() read integers from the String[] args and print the connections generated in the command line.

 */
public class DynamicConnectivityClient {

    /**
     * count() calculates the number of connect operations needed to achieve that all sites are in the same component.
     * @param n the size of the uf to be generated
     * @return numbers of connections generated
     */
    public static int countConnections(int n){
        int result = 0;
        Random random = new Random();
        UF uf = new UF_HWQUPC(n);
        while(!allConnected(uf)){
            int p = random.nextInt(n);
            int q = random.nextInt(n);
//            result++;
            if(!uf.isConnected(p,q)){
                uf.union(p,q);
                //System.out.println(p+" "+q);
                result++;
            }
        }
        return result;
    }

    /**
     * count() calculates the number of random paris needed to achieve that all sites are in the same component.
     * @param n the size of the uf to be generated
     * @return numbers of random pairs generated
     */
    public static int countRandomParis(int n){
        int result = 0;
        Random random = new Random();
        UF uf = new UF_HWQUPC(n);
        while(!allConnected(uf)){
            int p = random.nextInt(n);
            int q = random.nextInt(n);
            result++;
            if(!uf.isConnected(p,q)){
                uf.union(p,q);
                //System.out.println(p+" "+q);
//                result++;
            }
        }
        return result;
    }
    /**
     * Determine whether a UF is fully connected or not.
     * @param uf the uf needed for check the overall connectivity
     * @return {@code true} if the uf is fully connected;
     * {@code}false otherwise
     */
    public static boolean allConnected(UF uf){

        for(int i =0;i<uf.size()-1;i++){
            int j = i+1;
            if(!uf.isConnected(i,j)){
                return false;
            }

        }
        return true;
    }
    public static void main(String[] args){
        System.out.println("Starting counting the connections generated");
        List<Integer> list = new ArrayList<>();
        for(int i = 1; i<=Integer.parseInt(args[0]);i++){
            list.add(i);
        }


        List<String> data  = new ArrayList<>();
        for (Integer number:list){
            int countNum = countRandomParis(number);
            System.out.println(countNum +" random pairs generated for " + number + " sites");
            data.add(countNum+","+number);
        }

        File f = new File("Experiment_Result.csv");

        try {
            //noinspection ResultOfMethodCallIgnored
            f.createNewFile();
            FileWriter fWriter = new FileWriter("Experiment_Result2.csv");
            BufferedWriter bw = new BufferedWriter(fWriter);
            bw.write("Connections,Sites");
            bw.newLine();
            for (String row : data) {
                bw.write(row);
                bw.newLine();
            }
            bw.close();
        } catch (IOException e) {

            e.printStackTrace();
        }

    }
}

```



#### Data Visualization & Analysis (Step3)

```python
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
```


```python
df = pd.read_csv('/Users/xiaojialiang/Desktop/INFO6205/INFO6205-git/INFO6205 4/Experiment_Result.csv')
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }


    .dataframe tbody tr th {
        vertical-align: top;
    }
    
    .dataframe thead th {
        text-align: right;
    }

</style>

<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Connections</th>
      <th>Sites</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>6</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>13</td>
      <td>5</td>
    </tr>
  </tbody>
</table>

</div>




```python
x = df['Connections']
```


```python
y= df['Sites']
```


```python
plt.figure(figsize=(30,30))
plt.scatter(y,x,alpha=0.11)
plt.show()
```


​    
![png](/Users/xiaojialiang/Downloads/Untitled-2/output_5_0.png)
​    



```python
df2 = pd.read_csv('/Users/xiaojialiang/Desktop/INFO6205/INFO6205-git/INFO6205 4/Experiment_Result2.csv')
```


```python
x2 = df2['Connections']
y2= df2['Sites']
```


```python
plt.figure(figsize=(30,30))
plt.scatter(y2,x2,alpha=0.11)
plt.show()
```


​    
![png](/Users/xiaojialiang/Downloads/Untitled-2/output_8_0.png)
​    



```python
import numpy as np
from scipy.optimize import curve_fit
```


```python
def func(x,a,b,c,d):
    return a*x**0.5 + b*x + c*x**2 + d*x**3
```


```python
popt,pcov=curve_fit(func,y,x)
```


```python
print(popt)
```

    [-3.47225454e+01  4.76640328e+00  6.03651191e-05 -1.19845381e-09]



```python
a1=popt[0]
b1=popt[1]
c1=popt[2]
d1=popt[3]
```


```python
popt1=popt
```


```python
popt2,pcov=curve_fit(func,y2,x2)
```


```python
print(popt2)
```

    [-2.87675140e+01  4.63335854e+00  6.93333568e-05 -1.49068171e-09]



```python

```
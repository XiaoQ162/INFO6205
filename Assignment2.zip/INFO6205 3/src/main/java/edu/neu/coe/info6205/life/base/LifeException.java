package edu.neu.coe.info6205.life.base;

public class LifeException extends RuntimeException {
    public LifeException(String message) {
        super(message);
    }
}

### <center>Name Jialiang Xiao(NUID 001569847)</center>

# <center>Program Structures & Algorithms</center>

# <center>Spring 2021</center>

# <center>Assignment No.4</center>

### Task

We mentioned two alternatives for implementing Union-Find:

1. For weighted quick union, store the depth rather than the size;
2. For weighted quick union with path compression, do two loops, so that all intermediate nodes point to the root, not just the alternates.

For both of these, code the alternative and benchmark it against the implementation in the repository. You have all of that available from a previous assignment.

If you can explain why alternative #1 is unnecessary to be benchmarked, you may skip benchmarking that one.

Usual submission rules apply. 40 points only for this one.

### Explanation of why alternative #1 is unnecessary 

The main purpose of storing integers, which indicate the size or the depth of sub-trees, is to build weighted trees. Those integers are stored to keep track of trees. Before proving the performance are the same whether storing the depth or size, I want to point out that the performance improvement of weighted quick-union algorithm is based on the improvement of finding the root of one specific site, which is O(lgN) compared to O(N) of the finding of quick-union. More specifically, through building weighted tree, we reduce the finding time of the whole algorithm, which means that if we can ensure that the weighted tree is built successfully the performance of weighted quick-union won't change.

There are two kinds of situations that may cause the shape of the weighted tree to differ between using depth and using size during the unioning of two components(sub-trees). 

The first situation involves two subtrees, which have same depth but different size(Figure1).Let's call the left component the component1 and right component the component2 in Figure1. When using depth, it is both acceptable to connect component1 to component2 or to connect component2 to component1. When using size, the component1 will be connected to component2. In this case, the finding of the farest leaf nodes is the same which is lg2 (the depth of the merged component is 3). In conclusion, the performance would be the same.

Figure1

![截屏2021-03-02 下午7.09.00](/Users/xiaojialiang/Library/Application Support/typora-user-images/截屏2021-03-02 下午7.09.00.png)

The second kind of situation involves two subtrees, which have different depth and different size(Figure2). Let's call the left component the component1 and right component the component2 in Figure2. Component1 has depth of 2 and size of 5. Component2 has depth of 1 and size of 6. When using depth, component2 would be connected to component1, leaving the finding of the farest leaf nodes being lg2. When using size, component1 would be connected to component2, leaving the finding of the farest leaf nodes being lg3. In this situation, using depth slightly outperforms using size. But considering it is very rare for this kind of situations happen and the growth rate of lgN is relatively small, we can conclude that the performance is almost same whether using depth or using size.

![截屏2021-03-02 下午7.52.35](/Users/xiaojialiang/Library/Application Support/typora-user-images/截屏2021-03-02 下午7.52.35.png)

Figure2

### Output

Here is the screenshot of the result of benchmarking my implementation of height weighted quick union with fall path compression against the implementation in the repository. I separately benchmarked the unioning and finding of N sites.

### ![截屏2021-03-02 下午8.16.27](/Users/xiaojialiang/Library/Application Support/typora-user-images/截屏2021-03-02 下午8.16.27.png)Graphical Representation

Figure3 is the time benchmarked against n. Figure4 is the lgT against lgN.

![截屏2021-03-02 下午8.36.30](/Users/xiaojialiang/Desktop/截屏2021-03-02 下午8.36.30.png)

Figure3

![截屏2021-03-02 下午8.38.07](/Users/xiaojialiang/Library/Application Support/typora-user-images/截屏2021-03-02 下午8.38.07.png)

Figure4

### Analysis

From Figure3 we can see that both the unioning and finding of the two implementations of weighted quick union with path compression follows a nearly linear relationship with n(the number of sites). And from Figure3 and Figure4 we can see that the repo implementation outperforms my own implementation. This could be contributed to that in my implementation, i seperate the path compression as one individual function. Every time doing the path compression, there is one more fetching operation of the ref of path compression function in my implementation. Thus my implementation of WQUPC is slower. Additionally from figure3 we can see that the unioning always takes double the time of finding. It is because the union function needs to take twice the finding at one time. 

### Code

DynamicConnectivityClient.java(include the benchmarking)

```java
package edu.neu.coe.info6205.union_find;

import edu.neu.coe.info6205.util.Benchmark_Timer;
import edu.neu.coe.info6205.util.FileHandler;
import edu.neu.coe.info6205.util.FileHandlerImpl_CSV;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Supplier;

/**
 * This class is a client for dynamic connectivity problem solved with UF_HWQUPC.
 * The main() read integers from the String[] args and print the connections generated in the command line.

 */
public class DynamicConnectivityClient {

    /**
     * count() calculates the number of connect operations needed to achieve that all sites are in the same component.
     * @param n the size of the uf to be generated
     * @return numbers of connections generated
     */
    public static int countConnections(int n){
        int result = 0;
        Random random = new Random();
        UF uf = new UF_HWQUPC(n);
        while(!allConnected(uf)){
            int p = random.nextInt(n);
            int q = random.nextInt(n);
//            result++;
            if(!uf.isConnected(p,q)){
                uf.union(p,q);
                //System.out.println(p+" "+q);
                result++;
            }
        }
        return result;
    }

    /**
     * count() calculates the number of random paris needed to achieve that all sites are in the same component.
     * @param n the size of the uf to be generated
     * @return numbers of random pairs generated
     */
    public static int countRandomParis(int n){
        int result = 0;
        Random random = new Random();
        UF uf = new UF_HWQUPC(n);
        while(!allConnected(uf)){
            int p = random.nextInt(n);
            int q = random.nextInt(n);
            result++;
            if(!uf.isConnected(p,q)){
                uf.union(p,q);
                //System.out.println(p+" "+q);
//                result++;
            }
        }
        return result;
    }
    /**
     * Determine whether a UF is fully connected or not.
     * @param uf the uf needed for check the overall connectivity
     * @return {@code true} if the uf is fully connected;
     * {@code}false otherwise
     */
    public static boolean allConnected(UF uf){

        for(int i =0;i<uf.size()-1;i++){
            int j = i+1;
            if(!uf.isConnected(i,j)){
                return false;
            }

        }
        return true;
    }
    public static UF benchmarkUnion(UF uf){
        for(int i=0;i<uf.size()-1;i++){
            uf.union(i,i+1);
        }

        return uf;
    }

    public static WQUPC benchmarkUnion2(WQUPC uf){
        for(int i=0;i<uf.size()-1;i++){
            uf.union(i,i+1);
        }

        return uf;
    }

    public static int benchmarkFind(UF uf){
        for(int i=0;i<uf.size();i++){
            uf.find(i);
        }

        return 0;
    }

    public static int benchmarkFind2(WQUPC uf){
        for(int i=0;i<uf.size();i++){
            uf.find(i);
        }

        return 0;
    }

    public static UF hwqufpcInitialization(int n){
        UF uf = new UF_HWQUFPC(n);
        return uf;
    }
    public static WQUPC wqupcInitialization(int n){
        WQUPC uf = new WQUPC(n);
        return uf;
    }
    public static void main(String[] args){
        int sizeOfUF = 6553600;
        final Supplier<UF> hwqufpcSupplier = () -> {
            return hwqufpcInitialization(sizeOfUF);
        };

        final Supplier<WQUPC> wqupcSupplier = () -> {
            return wqupcInitialization(sizeOfUF);
        };

        System.out.println("Start benchmarking");
        final double t1 = new Benchmark_Timer<UF>(
                "benchmark union on my implementation",
                null,
                (xs) -> {
                    benchmarkUnion(xs);
                },
                null
        ).runFromSupplier(hwqufpcSupplier,1000);

        final double t2 = new Benchmark_Timer<WQUPC>(
                "benchmark union on repo implementation",
                null,
                (xs) -> {
                    benchmarkUnion2(xs);
                },
                null
        ).runFromSupplier(wqupcSupplier,1000);

        System.out.println("end benchmarking " + t1 + " " + t2);

        final Supplier<UF> hwqufpcCSupplier = () -> {
            return benchmarkUnion(hwqufpcInitialization(sizeOfUF));
        };

        final Supplier<WQUPC> wqupcCSupplier = () -> {
            return benchmarkUnion2(wqupcInitialization(sizeOfUF));
        };

        System.out.println("Start benchmarking");
        final double t3 = new Benchmark_Timer<UF>(
                "benchmark find on my implementation",
                null,
                (xs) -> {
                    benchmarkFind(xs);
                },
                null
        ).runFromSupplier(hwqufpcCSupplier,1000);

        final double t4 = new Benchmark_Timer<WQUPC>(
                "benchmark find on repo implementation",
                null,
                (xs) -> {
                    benchmarkFind2(xs);
                },
                null
        ).runFromSupplier(wqupcCSupplier,1000);
        System.out.println("end benchmarking " + t3 + " " + t4);

    }

    public static void assignment3(String[] args){
        System.out.println("Starting counting the connections generated");
        List<Integer> list = new ArrayList<>();
        for(int i = 1; i<=Integer.parseInt(args[0]);i++){
            list.add(i);
        }


        List<String> data  = new ArrayList<>();
        for (Integer number:list){
            int countNum = countRandomParis(number);
            System.out.println(countNum +" random pairs generated for " + number + " sites");
            data.add(countNum+","+number);
        }

        File f = new File("Experiment_Result.csv");

        try {
            //noinspection ResultOfMethodCallIgnored
            f.createNewFile();
            FileWriter fWriter = new FileWriter("Experiment_Result2.csv");
            BufferedWriter bw = new BufferedWriter(fWriter);
            bw.write("Connections,Sites");
            bw.newLine();
            for (String row : data) {
                bw.write(row);
                bw.newLine();
            }
            bw.close();
        } catch (IOException e) {

            e.printStackTrace();
        }

    }

}

```

UF_HWQUFPC.java(my own implementation of WQUPC with full path compression)

```java
/**
 * Original code:
 * Copyright © 2000–2017, Robert Sedgewick and Kevin Wayne.
 * <p>
 * Modifications:
 * Copyright (c) 2017. Phasmid Software
 */
package edu.neu.coe.info6205.union_find;

import java.util.Arrays;

/**
 * Height-weighted Quick Union with Full Path Compression
 */
public class UF_HWQUFPC implements UF {
    /**
     * Ensure that site p is connected to site q,
     *
     * @param p the integer representing one site
     * @param q the integer representing the other site
     */
    public void connect(int p, int q) {
        if (!isConnected(p, q)) union(p, q);
    }

    /**
     * Initializes an empty union–find data structure with {@code n} sites
     * {@code 0} through {@code n-1}. Each site is initially in its own
     * component.
     *
     * @param n               the number of sites
     * @param pathCompression whether to use path compression
     * @throws IllegalArgumentException if {@code n < 0}
     */
    public UF_HWQUFPC(int n, boolean pathCompression) {
        count = n;
        parent = new int[n];
        height = new int[n];
        for (int i = 0; i < n; i++) {
            parent[i] = i;
            height[i] = 1;
        }
        this.pathCompression = pathCompression;
    }

    /**
     * Initializes an empty union–find data structure with {@code n} sites
     * {@code 0} through {@code n-1}. Each site is initially in its own
     * component.
     * This data structure uses path compression
     *
     * @param n the number of sites
     * @throws IllegalArgumentException if {@code n < 0}
     */
    public UF_HWQUFPC(int n) {
        this(n, true);
    }

    public void show() {
        for (int i = 0; i < parent.length; i++) {
            System.out.printf("%d: %d, %d\n", i, parent[i], height[i]);
        }
    }

    /**
     * Returns the number of components.
     *
     * @return the number of components (between {@code 1} and {@code n})
     */
    public int components() {
        return count;
    }

    /**
     * Returns the component identifier for the component containing site {@code p}.
     *
     * @param p the integer representing one site
     * @return the component identifier for the component containing site {@code p}
     * @throws IllegalArgumentException unless {@code 0 <= p < n}
     */
    public int find(int p) {
        validate(p);
        int root = p;
        // TO BE IMPLEMENTED 在此处应该有path compression, notice in the class there is boolean pathCompression to determine whether the pathCompression is invoked or not
//        while (root != parent[p]){
//            if(pathCompression==true){
//                doFullPathCompression(root);
//            }
//            root=getParent(p);
//            p=getParent(p);
//        }
        while(root != parent[root]){
            root = parent[root];
        }
        if(pathCompression==true){
            doFullPathCompression(root,p);
        }
        return root;
    }

    /**
     * Returns true if the the two sites are in the same component.
     *
     * @param p the integer representing one site
     * @param q the integer representing the other site
     * @return {@code true} if the two sites {@code p} and {@code q} are in the same component;
     * {@code false} otherwise
     * @throws IllegalArgumentException unless
     *                                  both {@code 0 <= p < n} and {@code 0 <= q < n}
     */
    public boolean connected(int p, int q) {
        return find(p) == find(q);
    }

    /**
     * Merges the component containing site {@code p} with the
     * the component containing site {@code q}.
     *
     * @param p the integer representing one site
     * @param q the integer representing the other site
     * @throws IllegalArgumentException unless
     *                                  both {@code 0 <= p < n} and {@code 0 <= q < n}
     */
    public void union(int p, int q) {
        // CONSIDER can we avoid doing find again? but how?
        mergeComponents(find(p), find(q));
        count--;
    }

    @Override
    public int size() {
        return parent.length;
    }

    /**
     * Used only by testing code
     *
     * @param pathCompression true if you want path compression
     */
    public void setPathCompression(boolean pathCompression) {
        this.pathCompression = pathCompression;
    }

    @Override
    public String toString() {
        return "UF_HWQUFPC:" + "\n  count: " + count +
                "\n  path compression? " + pathCompression +
                "\n  parents: " + Arrays.toString(parent) +
                "\n  heights: " + Arrays.toString(height);
    }

    // validate that p is a valid index
    private void validate(int p) {
        int n = parent.length;
        if (p < 0 || p >= n) {
            throw new IllegalArgumentException("index " + p + " is not between 0 and " + (n - 1));
        }
    }

    private void updateParent(int p, int x) {
        parent[p] = x;
    }

    private void updateHeight(int p, int x) {
        height[p] += height[x];
    }

    /**
     * Used only by testing code
     *
     * @param i the component
     * @return the parent of the component
     */
    private int getParent(int i) {
        return parent[i];
    }

    private final int[] parent;   // parent[i] = parent of i
    private final int[] height;   // height[i] = height of subtree rooted at i
    private int count;  // number of components
    private boolean pathCompression;

    private void mergeComponents(int i, int j) {
        // TO BE IMPLEMENTED make shorter root point to taller one
        if(i==j) return;
        if(height[i]<height[j]){
            updateParent(i,j);
            updateHeight(j,i);
        }else{
            updateParent(j,i);
            updateHeight(i,j);
        }
    }

    /**
     * This implements the full path compression
     */
    private void doFullPathCompression(int root,int p) {
        // TO BE IMPLEMENTED update parent to value of grandparent
        while(p!= root){
            int newp = parent[p];
            parent[p] = root;
            p = newp;
        }
    }
}

```




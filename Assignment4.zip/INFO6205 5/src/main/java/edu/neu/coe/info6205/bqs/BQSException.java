/*
 * Copyright (c) 2017. Phasmid Software
 */

package edu.neu.coe.info6205.bqs;

public class BQSException extends Exception {
    public BQSException(String msg) {
        super(msg);
    }
}

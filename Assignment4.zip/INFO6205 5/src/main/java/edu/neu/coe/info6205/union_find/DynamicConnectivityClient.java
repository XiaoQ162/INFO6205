package edu.neu.coe.info6205.union_find;

import edu.neu.coe.info6205.util.Benchmark_Timer;
import edu.neu.coe.info6205.util.FileHandler;
import edu.neu.coe.info6205.util.FileHandlerImpl_CSV;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Supplier;

/**
 * This class is a client for dynamic connectivity problem solved with UF_HWQUPC.
 * The main() read integers from the String[] args and print the connections generated in the command line.

 */
public class DynamicConnectivityClient {

    /**
     * count() calculates the number of connect operations needed to achieve that all sites are in the same component.
     * @param n the size of the uf to be generated
     * @return numbers of connections generated
     */
    public static int countConnections(int n){
        int result = 0;
        Random random = new Random();
        UF uf = new UF_HWQUPC(n);
        while(!allConnected(uf)){
            int p = random.nextInt(n);
            int q = random.nextInt(n);
//            result++;
            if(!uf.isConnected(p,q)){
                uf.union(p,q);
                //System.out.println(p+" "+q);
                result++;
            }
        }
        return result;
    }

    /**
     * count() calculates the number of random paris needed to achieve that all sites are in the same component.
     * @param n the size of the uf to be generated
     * @return numbers of random pairs generated
     */
    public static int countRandomParis(int n){
        int result = 0;
        Random random = new Random();
        UF uf = new UF_HWQUPC(n);
        while(!allConnected(uf)){
            int p = random.nextInt(n);
            int q = random.nextInt(n);
            result++;
            if(!uf.isConnected(p,q)){
                uf.union(p,q);
                //System.out.println(p+" "+q);
//                result++;
            }
        }
        return result;
    }
    /**
     * Determine whether a UF is fully connected or not.
     * @param uf the uf needed for check the overall connectivity
     * @return {@code true} if the uf is fully connected;
     * {@code}false otherwise
     */
    public static boolean allConnected(UF uf){

        for(int i =0;i<uf.size()-1;i++){
            int j = i+1;
            if(!uf.isConnected(i,j)){
                return false;
            }

        }
        return true;
    }
    public static UF benchmarkUnion(UF uf){
        for(int i=0;i<uf.size()-1;i++){
            uf.union(i,i+1);
        }

        return uf;
    }

    public static WQUPC benchmarkUnion2(WQUPC uf){
        for(int i=0;i<uf.size()-1;i++){
            uf.union(i,i+1);
        }

        return uf;
    }

    public static int benchmarkFind(UF uf){
        for(int i=0;i<uf.size();i++){
            uf.find(i);
        }

        return 0;
    }

    public static int benchmarkFind2(WQUPC uf){
        for(int i=0;i<uf.size();i++){
            uf.find(i);
        }

        return 0;
    }

    public static UF hwqufpcInitialization(int n){
        UF uf = new UF_HWQUFPC(n);
        return uf;
    }
    public static WQUPC wqupcInitialization(int n){
        WQUPC uf = new WQUPC(n);
        return uf;
    }
    public static void main(String[] args){
        int sizeOfUF = 6553600;
        final Supplier<UF> hwqufpcSupplier = () -> {
            return hwqufpcInitialization(sizeOfUF);
        };

        final Supplier<WQUPC> wqupcSupplier = () -> {
            return wqupcInitialization(sizeOfUF);
        };

        System.out.println("Start benchmarking");
        final double t1 = new Benchmark_Timer<UF>(
                "benchmark union on my implementation",
                null,
                (xs) -> {
                    benchmarkUnion(xs);
                },
                null
        ).runFromSupplier(hwqufpcSupplier,1000);

        final double t2 = new Benchmark_Timer<WQUPC>(
                "benchmark union on repo implementation",
                null,
                (xs) -> {
                    benchmarkUnion2(xs);
                },
                null
        ).runFromSupplier(wqupcSupplier,1000);

        System.out.println("end benchmarking " + t1 + " " + t2);

        final Supplier<UF> hwqufpcCSupplier = () -> {
            return benchmarkUnion(hwqufpcInitialization(sizeOfUF));
        };

        final Supplier<WQUPC> wqupcCSupplier = () -> {
            return benchmarkUnion2(wqupcInitialization(sizeOfUF));
        };

        System.out.println("Start benchmarking");
        final double t3 = new Benchmark_Timer<UF>(
                "benchmark find on my implementation",
                null,
                (xs) -> {
                    benchmarkFind(xs);
                },
                null
        ).runFromSupplier(hwqufpcCSupplier,1000);

        final double t4 = new Benchmark_Timer<WQUPC>(
                "benchmark find on repo implementation",
                null,
                (xs) -> {
                    benchmarkFind2(xs);
                },
                null
        ).runFromSupplier(wqupcCSupplier,1000);
        System.out.println("end benchmarking " + t3 + " " + t4);

    }

    public static void assignment3(String[] args){
        System.out.println("Starting counting the connections generated");
        List<Integer> list = new ArrayList<>();
        for(int i = 1; i<=Integer.parseInt(args[0]);i++){
            list.add(i);
        }


        List<String> data  = new ArrayList<>();
        for (Integer number:list){
            int countNum = countRandomParis(number);
            System.out.println(countNum +" random pairs generated for " + number + " sites");
            data.add(countNum+","+number);
        }

        File f = new File("Experiment_Result.csv");

        try {
            //noinspection ResultOfMethodCallIgnored
            f.createNewFile();
            FileWriter fWriter = new FileWriter("Experiment_Result2.csv");
            BufferedWriter bw = new BufferedWriter(fWriter);
            bw.write("Connections,Sites");
            bw.newLine();
            for (String row : data) {
                bw.write(row);
                bw.newLine();
            }
            bw.close();
        } catch (IOException e) {

            e.printStackTrace();
        }

    }

}
